﻿using BookStoreAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BookStoreAPI.Interfaces
{
   public interface IBookRepository
    {
        Task<List<Book>> GetBooksAsync();

        Task<Book> GetBookById(int id);

        Task<Book> CreateBook(Book book);



    }
}
