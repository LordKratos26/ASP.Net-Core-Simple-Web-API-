﻿using BookStoreAPI.DataAccessLayer;
using BookStoreAPI.Interfaces;
using BookStoreAPI.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BookStoreAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BookController : ControllerBase
    {
        private readonly IBookRepository IbookRepo;

        public BookController(IBookRepository bookRepository )
        {
            IbookRepo = bookRepository;
        }

        [HttpGet]
        public async Task<IActionResult> GetAllBooks() 
        {
            
            return Ok(await IbookRepo.GetBooksAsync());
             
        }

        [HttpGet("{Id}")]
        public async Task<IActionResult> GetABookById(int Id)
        {
           
            return Ok(await IbookRepo.GetBookById(Id));
        }
        
        [HttpPost]
        public async Task<IActionResult> CreateBook([FromBody] Book book)
        {
           
            return Ok(await IbookRepo.CreateBook(book));
        }
    }
}
